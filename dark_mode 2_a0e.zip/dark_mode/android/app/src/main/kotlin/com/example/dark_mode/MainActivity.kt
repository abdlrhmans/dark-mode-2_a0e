package com.example.dark_mode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
